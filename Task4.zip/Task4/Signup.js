document.addEventListener("DOMContentLoaded", function () {
  // Your JavaScript code here
  const signup=document.getElementById("SignUp-btn");
const signin=document.getElementById("SignIn-btn");
const title=document.getElementById("Title");
const nameField=document.getElementById("Name");
const password=document.getElementById("Password");
const usermail=document.getElementById("Email");
const msg=document.getElementById("messagetoinform");
const submit=document.getElementById("login-button");
const Data = {
    Users: [] // Initialize an empty array to store user data
  };

signin.onclick = function(){
    clearInputFields();
    nameField.style.maxHeight="0";
    nameField.style.backgroundColor = "transparent"; 
    title.innerHTML="Sign In";
    signup.classList.remove("signup-btn");
    signup.classList.add("disable");
    signin.classList.remove("disable");
    signin.classList.add("signup-btn");
}
signup.onclick = function(){
    clearInputFields();
    nameField.style.maxHeight="65px";
    nameField.style.backgroundColor = "#E8E8E8"; 
    title.innerHTML="Sign Up";
    signup.classList.remove("disable");
    signup.classList.add("signup-btn");
    signin.classList.remove("signup-btn");
    signin.classList.add("disable");
}
submit.onclick=function(){
if (signup.classList.contains("signup-btn")) {
    // The "sign up" button has the "signup-btn" class
    console.log("Sign Up button has the 'signup-btn' class");
    const username=document.getElementById('usernameinput').value;
    const email=document.getElementById("emailinput").value;
    const password=document.getElementById("passwordinput").value;
    if(isEmailValid(email)){
      if (isPasswordValid(password)) {
        const userData = {
            User: username,
            Email: email,
            Password: password
          };
      
          // Push the user data object into the Users array
        Data.Users.push(userData);
        SaveData();
       displayErrorMessage('Registered Successfully...!');
      } else {
        displayErrorMessage('Password must contain 8 characters of capital&small letters,digits & special characters!');
      }
    }
    else{
       displayErrorMessage('Check your mail...!');
    }
} 
else {
        console.log("Sign In button has the 'disable' class");
        const loginmail = document.getElementById("emailinput").value;
        const loginpass = document.getElementById("passwordinput").value;
        const storedData = JSON.parse(localStorage.getItem('data'));
        if (storedData) {
          let found = false;
     
          for (const user of storedData.Users) {
            if (user.Email === loginmail && user.Password === loginpass) {
              found = true;
              window.location.href = "Welcome.html";
              break; // Exit the loop once a matching user is found
            }
          }
    
          if (!found) {
            displayErrorMessage('Incorrect Email or Password!');
          }
        }
        else {
          displayErrorMessage('No user data found. Please sign up first.');
        }
    
      }

 }

function isPasswordValid(password) {
    const passwordPattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&+=!]).{8,}$/;
  
    return passwordPattern.test(password);
}
function isEmailValid(email) {
    const emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
  
    return emailPattern.test(email);
}
function clearInputFields() {
        const usernameInput = document.getElementById("usernameinput");
        const emailInput = document.getElementById("emailinput");
        const passwordInput = document.getElementById("passwordinput");
        while (msg.firstChild) {
            msg.removeChild(msg.firstChild);
        }
        usernameInput.value = "";
        emailInput.value = "";
        passwordInput.value = "";
}
  
function SaveData(){
    localStorage.setItem('data', JSON.stringify(Data));
    
}
function displayErrorMessage(message) {
  // Create a new paragraph element
  const msgpara = document.getElementById("msgpara");

  if (!msgpara) {
    // If msgpara doesn't exist, create it
    const newMsgPara = document.createElement("p");
    newMsgPara.id = "msgpara"; // Set the id of the new element
    msg.appendChild(newMsgPara); // Append the new element to the msg div
  }

  // Set the text content of the existing or newly created <p> element
  document.getElementById("msgpara").textContent = message;
}

  
});