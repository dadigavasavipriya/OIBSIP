const inputtask=document.getElementById('inputtask');
const pendinglist=document.getElementById('PendingList');
const completedlist=document.getElementById("CompletedList");
function addtask(){
    if(inputtask.value.trim()===""){
        alert("Enter a task");
    }
    else{
        let li=document.createElement("li");
        li.innerHTML=inputtask.value;
        let span=document.createElement("span");
        span.innerHTML="&#10003";
        let divdel=document.createElement("div");
        divdel.innerHTML="&#10006;"
        li.appendChild(span);
        li.appendChild(divdel);
        pendinglist.querySelector('ul').appendChild(li);

    }
    inputtask.value="";
    saveData();
} 
pendinglist.addEventListener("click", function (e) {
    if (e.target.tagName === 'SPAN') {
            let li = e.target.parentElement;
            let clonedLi = li.cloneNode(true);
            clonedLi.removeChild(clonedLi.querySelector('span'));
            let divdel = document.createElement("div");
            divdel.innerHTML = "&#10006;";
            clonedLi.appendChild(divdel);
            completedlist.querySelector('ul').appendChild(clonedLi);
            li.remove();
            saveData(); // Remove the original li from pendinglist
        
    }
    if(e.target.tagName==='DIV'){
        e.target.parentElement.remove();
        saveData();
    }
});
completedlist.addEventListener("click",function(e){
    if(e.target.tagName==='DIV'){
        e.target.parentElement.remove();
        //saveData();
    }
});
function saveData() {
    // Store the innerText of the ul elements in localStorage
    localStorage.setItem("completeddata", completedlist.querySelector('ul').innerHTML);
    localStorage.setItem("pendingdata", pendinglist.querySelector('ul').innerHTML);
}

function showdata() {
    // Retrieve the data from localStorage
    const completedData = localStorage.getItem("completeddata");
    const pendingData = localStorage.getItem("pendingdata");

    // Set the innerHTML of the ul elements with the retrieved data
    completedlist.querySelector('ul').innerHTML = completedData;
    pendinglist.querySelector('ul').innerHTML = pendingData;
}
showdata();



